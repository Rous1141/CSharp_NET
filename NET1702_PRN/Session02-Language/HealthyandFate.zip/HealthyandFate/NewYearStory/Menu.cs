﻿using System;
namespace NewYearStory
{ 
	public class Menu
	{
/// <summary>
/// This is the main menu of the program.
/// </summary>
		public static void MainMenu()
		{
            Console.WriteLine("----------- Menu -----------");
            Console.WriteLine("1. BMI Calculator.");
            Console.WriteLine("2. Zodiac Sign Calculator.");
            Console.WriteLine("3. Exist Programs.");
            Console.WriteLine("============================");
            Console.Write("Choice: ");
        }
	}
}

